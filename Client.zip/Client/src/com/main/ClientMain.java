package com.main;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;

public class ClientMain {

    @SuppressWarnings("deprecation")
    public static void main(String[] args) {

        String url = "http://localhost:8080/BasicAuthExample/order";
        String username = "Shant";
        String password = "shant123";
        String authString = username + ":" + password;/*
	        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());*/
        byte[] authStringEnc = Base64.getEncoder().encode(authString.getBytes());
        System.out.println("Base64 encoded auth string: " + authStringEnc);
        HttpGet get = new HttpGet(url);
        String authHeader = "Basic " + new String(authStringEnc);
        get.setHeader("AUTHORIZATION", authHeader);
        get.setHeader("Content-Type", "application/json");
        get.setHeader("Accept", "application/json");

        /*	post.setHeader("X-Stream" , "true");*/
        HttpClient client = HttpClientBuilder.create().build();
        HttpResponse response = null;
        try {
            response = client.execute(get);
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(ClientMain.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (response.getStatusLine().getStatusCode() != 200) {
            System.err.println("Unable to connect to the server");
        }
        DataInputStream in = null;
        StringBuilder sb = null;
        try {
            sb = new StringBuilder();
            in = new DataInputStream(response.getEntity().getContent());
            String line;

            while ((line = in.readLine()) != null) {
                sb.append(line);
            }
            in.close();
        } catch (IOException io) {
            io.printStackTrace();
        }

        String output = sb.toString();
        System.out.println("response: " + output);
    }

}

