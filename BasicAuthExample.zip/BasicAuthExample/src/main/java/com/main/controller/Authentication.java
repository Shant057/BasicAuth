package com.main.controller;



import javax.websocket.server.PathParam;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.main.bean.Order;


@RestController
public class Authentication {

	@GetMapping("/order")
	public Object getUserById(@PathParam("orderId") Integer orderId, 
			@RequestHeader("authorization") String authString){

		if(!isUserAuthenticated(authString)){
			return "{\"error\":\"User not authenticated\"}";
		}
		Order ord = new Order();
		ord.setCustomer("Bunny");
		ord.setAddress("Bangalore");
		ord.setAmount(2000);
		return ord;
	}


	private boolean isUserAuthenticated(String authString){

		String decodedAuth = "";
		// Header is in the format "Basic 5tyc0uiDat4"
		// We need to extract data before decoding it back to original string
		String[] authParts = authString.split("\\s+");
		String authInfo = authParts[1];
		// Decode the data back to original string
		byte[] bytes = null;
		try {
			bytes = new Base64().decode(authInfo);
		} catch (Exception e) {

			e.printStackTrace();
		}
		decodedAuth = new String(bytes);
		System.out.println(decodedAuth);


		//validation code goes here....
		if(!decodedAuth.equals("Shant:shant123")){
			return false;
		}

		return true;
	}

}
