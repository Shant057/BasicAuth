package com.main.bean;

public class Order {
	
	private String customer;
	private String address;
	private int amount;
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Order [customer=" + customer + ", address=" + address
				+ ", amount=" + amount + "]";
	}
	
	

}
